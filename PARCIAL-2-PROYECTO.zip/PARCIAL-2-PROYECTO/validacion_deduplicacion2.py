#codigo almacenado en el host 
# ruta /home/test/sistemasdistribuidos/

import pika
import json
import os
import requests

# Configuración de RabbitMQ
connection = pika.BlockingConnection(pika.ConnectionParameters('localhost'))
channel = connection.channel()
channel.queue_declare(queue='formulario_queue')

def consumir_api_zookeeper(formulario):
    # Obtener la ubicación de la API desde el clúster de ZooKeeper (puedes usar una biblioteca para esto)
    # Por simplicidad, asumimos que la API está en http://zookeeper-leader:8080/api/endpoint
    url = 'http://zookeeper-leader:8181/api/endpoint'

    # Realizar la solicitud a la API con el formulario JSON
    response = requests.post(url, json=formulario)

    # Procesar la respuesta de la API según tus necesidades
    if response.status_code == 200:
        print('Formulario validado y deduplicado correctamente.')
    else:
        print('Error al procesar el formulario en la API.')

def procesar_formulario(ch, method, properties, body):
    # Decodificar formulario JSON
    formulario = json.loads(body)

    # Realizar validación y deduplicación local (opcional)
    # ...

    # Consumir la API de ZooKeeper para la validación y deduplicación
    consumir_api_zookeeper(formulario)

    # Guardar formulario en un archivo local (opcional)
    with open('formulario.json', 'w') as file:
        json.dump(formulario, file)

    print('Formulario procesado y guardado localmente.')

# Configuración de RabbitMQ para recibir mensajes
channel.basic_consume(queue='formulario_queue', on_message_callback=procesar_formulario, auto_ack=True)

# Iniciar el bucle de RabbitMQ para recibir mensajes
channel.start_consuming()
